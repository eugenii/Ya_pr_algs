import sys

def solve():
    data = sys.stdin.buffer.read().split()
    n = int(data[0])
    
    # Создаем массив расстояний
    dist = [0] * n
    
    # Первый проход: расстояния до ближайшего нуля слева
    last_zero = -n  # вместо -10**9
    idx = 1  # индекс в data
    
    for i in range(n):
        # Быстрая проверка на 0: если байт равен 48 (ASCII для '0')
        if data[idx] == b'0':
            last_zero = i
        dist[i] = i - last_zero
        idx += 1
    
    # Второй проход: минимум с расстояниями справа
    last_zero = n  # вместо 10**9
    result = []
    
    # Идем с конца, но по data тоже с конца
    idx = len(data) - 1
    
    for i in range(n - 1, -1, -1):
        if data[idx] == b'0':
            last_zero = i
        right_dist = last_zero - i
        if right_dist < dist[i]:
            result.append(str(right_dist))
        else:
            result.append(str(dist[i]))
        idx -= 1
    
    # Выводим в обратном порядке
    sys.stdout.write(' '.join(reversed(result)))

if __name__ == "__main__":
    solve()