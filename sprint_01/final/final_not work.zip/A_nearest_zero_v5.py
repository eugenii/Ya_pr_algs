import sys

def main():
    # Читаем количество домов
    n_line = sys.stdin.readline()
    if not n_line:
        return
    n = int(n_line)
    
    zeros = []  # список индексов нулей
    pos = 0  # позиция дома (0-based)
    current_num = []
    
    for _ in range(n):
        # Читаем число посимвольно
        while True:
            ch = sys.stdin.read(1)
            if ch in (' ', '\n', ''):
                break
            current_num.append(ch)
        
        # Проверяем, является ли число нулем
        if current_num and current_num[0] == '0' and len(current_num) == 1:
            zeros.append(pos)
        
        pos += 1
        current_num.clear()  # очищаем для следующего числа
    
    print(zeros)  # для проверки

if __name__ == "__main__":
    main()