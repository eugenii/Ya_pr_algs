import sys

n_line = sys.stdin.readline()

n = int(n_line)

# Инициализируем результат
result = [0] * n

# Первый проход слева направо
last_zero = -10**9
pos = 0
num_str = ""

while pos < n:
    ch = sys.stdin.read(1)
    if ch == ' ' or ch == '\n' or ch == '':
        if num_str:
            num = int(num_str)
            if num == 0:
                last_zero = pos
            result[pos] = pos - last_zero
            pos += 1
            num_str = ""
        if ch == '':
            break
    else:
        num_str += ch

# Второй проход справа налево
last_zero = 10**9
for i in range(n - 1, -1, -1):
    if result[i] == 0:  # Это был ноль в исходных данных
        last_zero = i
    result[i] = min(result[i], last_zero - i)

print(*result)